^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package examples_rclpy_minimal_action_client
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.15.1 (2022-11-07)
-------------------

0.15.0 (2022-03-01)
-------------------

0.14.0 (2022-01-14)
-------------------
* Update maintainers to Aditya Pande and Shane Loretz (`#332 <https://github.com/ros2/examples/issues/332>`_)
* Updated maintainers (`#329 <https://github.com/ros2/examples/issues/329>`_)
* Contributors: Aditya Pande, Audrow Nash

0.13.0 (2021-10-18)
-------------------

0.12.0 (2021-08-05)
-------------------

0.11.2 (2021-04-26)
-------------------
* Use underscores instead of dashes in setup.cfg (`#310 <https://github.com/ros2/examples/issues/310>`_)
* Contributors: Ivan Santiago Paunovic

0.11.1 (2021-04-12)
-------------------

0.11.0 (2021-04-06)
-------------------

0.10.3 (2021-03-18)
-------------------
* Using asyncio with ros2 action client (`#301 <https://github.com/ros2/examples/issues/301>`_)
* Contributors: alemme

0.10.2 (2021-01-25)
-------------------

0.10.1 (2020-12-10)
-------------------
* Update maintainers (`#292 <https://github.com/ros2/examples/issues/292>`_)
* Contributors: Shane Loretz

0.10.0 (2020-09-21)
-------------------
* Added missing linting tests (`#287 <https://github.com/ros2/examples/issues/287>`_)
* Contributors: Allison Thackston

0.9.2 (2020-06-01)
------------------

0.9.1 (2020-05-26)
------------------

0.9.0 (2020-04-30)
------------------

0.8.2 (2019-11-19)
------------------
* Fix client_cancel example. (`#258 <https://github.com/ros2/examples/issues/258>`_)
* Contributors: Michel Hidalgo

0.8.1 (2019-10-24)
------------------

0.7.3 (2019-05-29)
------------------
* Fix InvalidHandle exception in action client examples (`#246 <https://github.com/ros2/examples/issues/246>`_)
* Contributors: Siddharth Kucheria

0.7.2 (2019-05-20)
------------------

0.7.1 (2019-05-08)
------------------
* Fix rclpy action client examples
* Contributors: Jacob Perron

0.7.0 (2019-04-14)
------------------
* Added rclpy action examples. (`#222 <https://github.com/ros2/examples/issues/222>`_)
* Contributors: Jacob Perron

0.6.2 (2019-02-08)
------------------

0.6.1 (2018-12-07)
------------------

0.6.0 (2018-11-20)
------------------

0.5.1 (2018-06-27)
------------------

0.5.0 (2018-06-26)
------------------

0.4.0 (2017-12-08)
------------------

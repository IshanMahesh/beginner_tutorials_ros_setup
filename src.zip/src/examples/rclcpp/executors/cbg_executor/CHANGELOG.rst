^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package examples_rclcpp_cbg_executor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.15.1 (2022-11-07)
-------------------

0.15.0 (2022-03-01)
-------------------
* Improve scheduling configuration of examples_rclcpp_cbg_executor package (`#331 <https://github.com/ros2/examples/issues/331>`_)
* Added jitter measurement to examples_rclcpp_cbg_executor. (`#328 <https://github.com/ros2/examples/issues/328>`_)
* Contributors: Ralph Lange

0.14.0 (2022-01-14)
-------------------

0.13.0 (2021-10-18)
-------------------
* Fix deprecated subscriber callbacks (`#323 <https://github.com/ros2/examples/issues/323>`_)
* Contributors: Abrar Rahman Protyasha

0.12.0 (2021-08-05)
-------------------
* Remove use of get_callback_groups(). (`#320 <https://github.com/ros2/examples/issues/320>`_)
* Contributors: Chris Lalancette

0.11.2 (2021-04-26)
-------------------

0.11.1 (2021-04-12)
-------------------
* Fix clang warnings about type mismatches. (`#309 <https://github.com/ros2/examples/issues/309>`_)
* Contributors: Chris Lalancette

0.11.0 (2021-04-06)
-------------------
* Support for cbg_executor package on QNX (`#305 <https://github.com/ros2/examples/issues/305>`_)
* Contributors: joshua-qnx

0.10.3 (2021-03-18)
-------------------
* Demo for callback-group-level executor concept. (`#302 <https://github.com/ros2/examples/issues/302>`_)
* Contributors: Ralph Lange

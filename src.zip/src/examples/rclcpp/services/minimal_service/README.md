# Minimal "addition\_server" cookbook recipes

This package contains a few examples which show how to create services.
